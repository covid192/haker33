# Instagram username checker

[![Version](https://img.shields.io/badge/Version-v1.0.0-blue)]()
[![Python](https://img.shields.io/badge/Python-v%2B-blue)]()
[![Telegram](https://img.shields.io/badge/Telegram-blue)](https://t.me/ssscw)


A simple tool to get usernames for the Instagram account for free. 
Note I do not accept to sell the tool or take it for sale

### System 

-  Linux
-  Windows ( CMD ) 
-  Android ( Termux ) 

### Install Tool

```
-  pkg update && pkg upgrade
-  pkg install python -y
-  pkg install python2 -y
-  pkg install git -y
-  git clone https://github.com/kanekikon/checker
```


### Run

```
[-] cd checker 
[-] chmod +x checker.py
[-] python checker.py
```

### Stop

```
[!] Ctrl + Z
```
